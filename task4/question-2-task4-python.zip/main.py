list=input("enter the string")
print(list[::2])